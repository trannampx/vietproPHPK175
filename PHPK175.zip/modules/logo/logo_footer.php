<div id="logo-2" class="col-lg-3 col-md-6 col-sm-12">
    <h2><a href="#"><img src="images/logo-footer.png"></a></h2>
    <p>
        Vietpro Academy thành lập năm 2009. Chúng tôi đào tạo chuyên sâu trong 2 lĩnh vực là Lập trình Website & Mobile
        nhằm cung cấp cho thị trường CNTT Việt Nam những lập trình viên thực sự chất lượng, có khả năng làm việc độc
        lập, cũng như Team Work ở mọi môi trường đòi hỏi sự chuyên nghiệp cao.
    </p>
</div>