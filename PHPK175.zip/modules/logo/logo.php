<div id="logo" class="col-lg-3 col-md-3 col-sm-12">
            	<h1><a href="#"><img class="img-fluid" src="images/logo.png"></a></h1>
</div>